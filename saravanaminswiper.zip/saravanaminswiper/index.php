<?php
// Version 1.0 - 25 Aug 2019
?>
<html>
  <head>
    <title>Saravana Interview Task</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  </head>
  <body>
    <h1>Minesweeper code</h1>
    <?php
      $output = "";
      include('input_handler.php');
      include('grid_gen.php');
      $grid_gen->generate();
    ?>
  </body>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</html>